const { CommandInteraction, Client } = require("discord.js");
const tokenModel = require("../../modals/users");
const badgeEmojis = require("../../settings/badges.json");
var sleep = require('thread-sleep');



module.exports = {
    name: "addbadge",
    description: "Adds a badge to the profile",
    permissions: [""],
    options: [
        {
          name: 'user',
          description: 'the user on which the badge needs to be added',
          required: true,
          type: "USER"
        },
        {
            name: "badge",
            description: 'the badge to add',
            required: true,
            type: "STRING",
            choices: [
                {
                    name: "trial staff",
                    value: 'trialstaff'
                },
                {
                    name: 'staff member',
                    value: 'staffmember'
                },
                {
                    name: 'bot admin',
                    value: 'botadmin'
                },
                {
                    name: 'bot dev',
                    value: 'botdev'
                },
                {
                    name: 'middle man',
                    value: 'middleman'
                },
                {
                    name: 'exchanger',
                    value: 'exchanger'
                },
                {
                    name: 'donator',
                    value: 'donator'
                },
                {
                    name: 'owner',
                    value: 'owner'
                }
            ]
        }
    ],
    /**
     *
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */
    run: async (client, interaction, args) => {






        await interaction.deferReply();
        if(interaction.member.id !== "758961525330411521") {
            return interaction.editReply({content: 'Since when are you the developer of the bot? || The command is restriced only to the owners of the bot ||'})
        }
        


        const userrid = interaction.options.getUser("user", true);
        
        const userid = userrid.id;
       	
        
        const user = client.users.cache.get(userid)


        let data = await tokenModel.findOne({ userID: userid })
        if (!data) {

            let token = client.functions.randToken();

            await new tokenModel({
                token: token,
                userID: userid,
                badges: `${badgeEmojis["User"]} User`,
                shop: "Not Set",
            }).save();
        }
        sleep(2000)

        let ook = await tokenModel.findOne({ userID: userid })

        const badgeToAdd = interaction.options.getString("badge", true)

        switch (badgeToAdd) {
            case "trialstaff":
                let toAdd = { badges: `${badgeEmojis["trialstaff"]} Trial Staff` }
                await tokenModel.findOneAndUpdate({ userId: userid }, { $push: toAdd });

                return interaction.editReply({ content: 'Added Trial Staff' })
                break;

            case "donator":
                let tooAdd = { badges: `${badgeEmojis["donator"]} Donator` }
                await tokenModel.findOneAndUpdate({ userId: userid }, { $push: tooAdd });
                return interaction.editReply({ content: 'Added Donator' })
                break;

            case "exchanger":
                let toooAdd = { badges: `${badgeEmojis["exchanger"]} Exchanger` }
                await tokenModel.findOneAndUpdate({ userId: userid }, { $push: toooAdd });
                return interaction.editReply({ content: 'Added Exchanger' })
                break;

            case "middleman":
                let middlememe = { badges: `${badgeEmojis["middleman"]} Middle Man` }
                await tokenModel.findOneAndUpdate({ userId: userid }, { $push: middlemene });
                return interaction.editReply({ content: 'Added Middleman' })
                break;

            case "staffmember":
                let jatin = { badges: `${badgeEmojis["staffmember"]} Staff Member` }
                await tokenModel.findOneAndUpdate({ userId: userid }, { $push: jatin });
                return interaction.editReply({ content: 'Added Staff Member' })
                break;

                case "botdev":
                let ooooAdd = {badges: `${badgeEmojis["botdev"]} Bot Dev`}
                await tokenModel.findOneAndUpdate({userId: userid}, {$push: ooooAdd });
                return interaction.editReply({content: 'Added Bot Dev'})
                break;

                case "botadmin":
                let brubru = {badges: `${badgeEmojis["botadmin"]} Bot Admin`}
                await tokenModel.findOneAndUpdate({userId: userid}, {$push: brubru});
                return interaction.editReply({content: 'Added Bot Admin'})
                break;
                

                case "owner":
                let bruh = {badges: `${badgeEmojis["owner"]} Owner`}
                await tokenModel.findOneAndUpdate({userId: userid}, {$push: bruh });
                return interaction.editReply({content: 'Added Owner'})
                break;


            default:
                break;
        }



    },
};