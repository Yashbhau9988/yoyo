const { CommandInteraction, Client } = require("discord.js");

module.exports = {
    name: "embed",
    description: "create embeds",
    options: [
      {
        name: "channel",
        description: "channel where to send embed",
        required: true,
        type: "CHANNEL",
        channelTypes: ["GUILD_TEXT"],
      },
      {
        name: "title",
        description: "title of embed",
        required: true,
        type: "STRING",
      },
      {
        name: "description",
        description: "description of embed [ +n+ = NewLine ]",
        required: true,
        type: "STRING",
      },
      {
        name: "footer",
        description: "footer of embed",
        required: true,
        type: "STRING"
      },
    ],
    permissions : ["EMBED_LINKS"],
    /**
     *
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */
    run: async (client, interaction, args) => {
      const title = interaction.options.getString("title", true)
      const description = interaction.options.getString("description", true)
      const footer = interaction.options.getString("footer", true)

    const channel = interaction.options.getChannel("channel", true)

      let cha = client.channels.cache.get(channel.id)
      

      let tu = (String(description).substring(0, 2048).split("+n+").join("\n"))

      let hi = client.functions.opEmbed(`${title}`, `${tu}`, `${footer}`)

      cha.send({embeds: [hi]});

      let bye = client.functions.opEmbed("Success", `✅ Embed has been sent to ${channel}`, "Miracle Codes")

      await interaction.followUp({embeds: [bye], ephermal: true})
      
    },
};