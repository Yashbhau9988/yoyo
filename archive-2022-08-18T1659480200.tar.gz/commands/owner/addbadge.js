const {
 Client,
 Message,
 MessageEmbed,
 MessageActionRow,
 MessageButton,
} = require("discord.js");

const tokenModel = require("../../modals/users");
const badgeEmojis = require("../../settings/badges.json");
const fs = require("fs");

module.exports = {
 name: "addbadge",
 description: "Evaluate code.",
 /**
  * @param {Client} client
  * @param {Message} message
  * @param {String[]} args
  */
 run: async (client, message, args) => {
   if (message.author.id !== "980908670021959680") return;
     
   let user = args.slice(0).join(" ")
   if(!user) return;

    const regex = /(?<id>[0-9]{18})/i;

    let con = user.match(regex)

    let userid = con.groups.id;
           
    const member = client.users.cache.get(userid)
    if(!member) {
      let membed = client.functions.failEmbed("Failed", `<:cross:982377277801234452> Unable to find the user.`)
      return message.channel.send({embeds: [membed]})
    }
     
    let badge = args.slice(1).join(" ")
    if(!badge) return;
    
    let broo = fs.readdir("../../settings/badges.json", )
    
    console.log(bdgee)
     
    let bdg = `${badgeEmojis["New User"]} New User`;
    console.log(bdg)
     
   
     
   
 }
}