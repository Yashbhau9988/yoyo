const {
    Message,
    Client,
    MessageEmbed,
    MessageActionRow,
    MessageButton,
  } = require("discord.js");
  const userModel = require("../../modals/vouches");
  const vouchesModel = require("../../modals/vouch");
  const tokenModel = require("../../modals/users");
  const ee = require("../../settings/embed.json");
  const blackModel = require("../../modals/blacklisted");
  
  module.exports = {
    name: "addbl",
    aliases: [],
    permissions: ["SEND_MESSAGES"],
    guildOnly: true,
    reportStaffOnly: true,
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {


        let user =
      message.mentions.users.first() ||
      client.users.cache.get(args[0])

    const member = client.users.cache.get(user.id);

    let reason = args.slice(1).join(" ")

    if(!reason) return message.reply({content: 'Please provide a reason'})

    let data = await blackModel.findOne({userID: user.id})

    if(data) {
        return message.reply({content: 'The user is already marked as blacklisted.'})
    }

    if(!data) {
        new blackModel({
            userID: user.id,
            blacklisted: true,
            reason: reason,
            markedBy: `${message.author.tag} (${message.author.id})`
        }).save();
    }

    message.reply({content: 'Marked as blacklisted.'})


    let msgg = `<:tickkk:982377244439760986> User: ${member} | ${member.tag} | ${member.id} is now blacklisted.\n<a:mm_RedAlertsign:983108383555080232> Reason - \`${reason}\``

    await client.channels.cache.get("995641757939273850").send({content: msgg})

    }
}