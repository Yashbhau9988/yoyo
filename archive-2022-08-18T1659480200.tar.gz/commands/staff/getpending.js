const vouchesModel = require("../../modals/vouch");
const ee = require("../../settings/embed.json");
const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");

module.exports = {
    name: "getpending",
    description: 'gives a list of pending vouches to check.',
    vouchStaffOnly: true,
    run: async (client, message, args) => {

        const embed = new MessageEmbed()
        .setTitle("Vouch System | Reco")
        .setColor(ee.embed_color)
        .setDescription(`Get all pending vouches by clicking below button.`)
        
        const row = new MessageActionRow()
        .addComponents(
            new MessageButton()
            .setStyle("SUCCESS")
            .setCustomId("pending")
            .setLabel("Pending Vouches")
            .setEmoji("982376836619194428")
        );


        await client.channels.cache.get("1001067039940681848").send({embeds: [embed], components: [row]})

    }
}