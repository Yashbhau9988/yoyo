const { Message, Client, MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const userModel = require("../../modals/vouches");
const vouchModel = require("../../modals/vouch");
const ee = require("../../settings/embed.json")
const checkModel = require("../../modals/checking");
const vouch = require("../../modals/vouch");

module.exports = {
    name: "decline",
    aliases: [],
    permissions : ["SEND_MESSAGES"],
    description: 'Decline the vouch.',
    vouchStaffOnly: true,
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {

     

        let code = args[0]
        let regex = "[a-zA-Z]+"
        if(code.match(regex)) {
            return;
        }

        if(!code) {
            return message.reply({content: "Give a valid code to search for vouch"})
        }
        let data = await vouchModel.findOne({vouchNum: code})
        if(!data) return message.reply({content: "Could not find code in database"})
        if(data.Status === "Accepted"){
            return message.reply({content: "This is already Approved"})
        }
        let reason = args.slice(1).join(" ") || "Not specified!";

        let roww = new MessageActionRow()
            .addComponents(
                new MessageButton()
                .setStyle("LINK")
                .setLabel("Support Server")
                .setURL("https://discord.gg/recobot"),
            )


            let userid = data.userID;

            let dete = await userModel.findOne({userID: userid})

            let pen_vouches = dete.pen_vouches - 1;
            let dec_vouches = dete.dec_vouches + 1;

            await userModel.findOneAndUpdate({userID: userid}, {pen_vouches: pen_vouches})
            await userModel.findOneAndUpdate({userID: userid}, {dec_vouches: dec_vouches})
            await vouchModel.findOneAndUpdate({vouchNum: code}, {Status: "Declined"})




            let embed = new MessageEmbed()
                    // .setAuthor({name: 'Shibaaa', iconURL: 'https://cdn.discordapp.com/emojis/982377277801234452.webp?size=128&quality=lossless'})
                    .setTitle("Vouch Notification System")
                    .setDescription(`<:cross:982377277801234452> Your Vouch Number \`${code}\` has been declined\n\n__**Reason**__: ${reason}\n\n\`Responsible Moderator: ${message.author.tag} (${message.author.id})\``)
                    .setColor(ee.embed_color)
                    .setFooter({text: 'Shibaaaa', iconURL: ee.embed_footericon});


                    try {
                    let userr = client.users.cache.get(userid)
                    userr.send({embeds: [embed], components: [roww]})
                    } catch (error) {
                        console.log(error)
                    }

                    await checkModel.findOneAndUpdate({vouchNum: code}, {Status: "Rejected"})
                    await checkModel.findOneAndUpdate({vouchNum: code}, {Reason: reason})

                    await message.channel.send({content: 'Rejected'})

            let embedd = new MessageEmbed()
                    .setTitle("Vouch Changes")
                    .setDescription(`Some Changes were made to vouch number \`${code}\` :\n\nChanges done by: \`${message.author.tag} (${message.author.id})\`\nThe Vouch was: \`Declined\`\nReason: \`${reason}\`  `)
                    .setColor(ee.embed_color)
                    .setFooter({text: ee.embed_footertext, iconURL: ee.embed_footericon})

                    let ch = "982942033012465665";
                    let cha = client.channels.cache.get(ch)

                    cha.send({embeds: [embedd]})
       }
      } 