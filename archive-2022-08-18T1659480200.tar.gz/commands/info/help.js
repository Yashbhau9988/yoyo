const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js")
const ee = require("../../settings/embed.json") 

module.exports = {
    name: 'help',
    aliases: ["commands"],
    description: 'Shows help message',
    run: async(client, message, args) => {


    // kya use puch rahe ap?

    const embed = new MessageEmbed()
    .setTitle("Command List")
    .setColor(ee.embed_color)
    .setThumbnail(client.user.displayAvatarURL())
    .setDescription(`Welcome to Reco v1!\n**User Commands**\nAll general commands are displayed here\n**+profile** Displays your or mentioned user's profile\n**+vouch/rep** Adds a positive vouch to the mentioned user.\n**+token** Sends your token in dm\n**+badges** Shows all of the bot badges\n**+shop** *Coming soon!*\n**+discord** *Coming Soon!*\n**+invite** Shows the bot invite link\n**+vouches** - Shows the vouches with comments of the user!`)
    .setFooter({text: "Reco bot", iconURL: ee.embed_footericon})

    return message.channel.send({embeds: [embed]})


    }
}