const { MessageActionRow, MessageEmbed, MessageButton } = require("discord.js");
const ee = require("../../settings/embed.json")

module.exports = {
    name: 'invite',
    aliases: ["inv"],
    description: 'Shows the bot invite link.',
    run: async (client, message) => {
        let row = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setStyle("LINK")
                    .setLabel("Support Server")
                    .setEmoji("983470508051947560")
                    .setURL("https://discord.com/api/oauth2/authorize?client_id=996375131591024690&permissions=67497025&scope=bot%20applications.commands"),


                new MessageButton()
                    .setStyle("LINK")
                    .setLabel("Support Server")
                    .setURL("https://discord.gg/7x3uwVmmqq"),

            );

        let embed = new MessageEmbed()
            .setTitle("Reco | Invite")
            .setColor(ee.embed_color)
            .setDescription(``)
            .setFooter({ text: 'Developed by J8TIN#1111', iconURL: ee.embed_footericon })

        await message.channel.send({ embeds: [embed, embed_2, embed_3] })



    }
}