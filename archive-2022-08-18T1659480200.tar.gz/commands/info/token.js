const {  MessageActionRow, Modal, TextInputComponent, Message, Client, MessageEmbed } = require("discord.js");
const tokenModel = require("../../modals/users");
const badges = require("../../settings/badges.json");

module.exports = {
    name: "token",
    aliases: [],
    permissions : ["SEND_MESSAGES"],
    description: "Sends secret token",
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {
        if(message.guild) {
            return message.reply({content: 'The command is restricted to be used in dms only!'})
        }
        let data = await tokenModel.findOne({userID: message.author.id})

        if(data) {
            await message.author.send({embeds: [
                new MessageEmbed()
                .setAuthor({name: 'Secret Token', iconURL: 'https://cdn.discordapp.com/emojis/982377244439760986.webp?size=128&quality=lossless'})
                .setColor("AQUA")
                .setDescription(`Your Secret Token - || ${data.token} ||`)
                .setTimestamp()
            ]}).then((m) => {
                m.pin()
            })
            // console.log("1")
            return;
        }

        if(!data) {


            let token = client.functions.randToken()

            new tokenModel({
                userID: message.author.id,
                badges: `${badges["User"]}User`,
                token: token,
                shop: "Not set"
            }).save();

            await message.author.send({embeds: [
                new MessageEmbed()
                .setAuthor({name: 'Secret Token', iconURL: 'https://cdn.discordapp.com/emojis/982377244439760986.webp?size=128&quality=lossless'})
                .setColor("AQUA")
                .setDescription(`Your Secret Token - || ${token} ||`)
                .setTimestamp()
            ]}).then((m) => {
                m.pin();
            })
            // console.log("2")
            return;
        }


    },
};