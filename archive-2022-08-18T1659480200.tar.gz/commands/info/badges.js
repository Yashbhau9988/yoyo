const {  MessageActionRow, Modal, TextInputComponent, Message, Client, MessageEmbed } = require("discord.js");
const ee = require("../../settings/embed.json")

module.exports = {
    name: "badges",
    aliases: [],
    permissions : ["SEND_MESSAGES"],
    description: "Shows all the badges or bot",
    //guildOnly: true,
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {
        const embed = new MessageEmbed()
        .setTitle("Reco Badges")
        .setDescription(`<:owner:983470971107307600> OWNER 
        <:emoji_12:982596891944579102>  BOT DEV
        <:emoji_11:982596868271915059>  BOT ADMIN
        <:directadmin:982729841780592651>   STAFF MEMBER 
        <:trialstaff:983470902685610115> TRIAL STAFF
        <:mm:982730142373777458>  MIDDLEMAN
        <:mm_exchanges:982730204952801300>  EXCHANGER
        <:recodonator:983470636871614476> DONATER 
        <:recouser:983470508051947560>  RECO USER 
        <:emoji_21:983349444261081088> 50+ VOUCHES 
        <:emoji_23:983349566508265543> 100+ VOUCHES 
        <:emoji_24:983349622934208554> 250+ VOUCHES
        <:emoji_22:983349502691930132>  550+ VOUCHES 
        <:emoji_27:983349799933861948>  TOP 10+ VOUCHES `)
        .setColor(ee.embed_color)
        .setFooter({text: ee.embed_footertext, iconURL: ee.embed_footericon})

        await message.channel.send({embeds: [embed]})

    },
};