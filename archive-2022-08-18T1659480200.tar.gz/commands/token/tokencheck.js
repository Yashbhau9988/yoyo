const { Message, Client } = require("discord.js");
const userModel = require("../../modals/vouches");
const vouchModel = require("../../modals/vouch");
const ee = require("../../settings/embed.json")
const checkModel = require("../../modals/checking");
const vouch = require("../../modals/vouch");
const tokenModel = require("../../modals/users");


module.exports = {
    name: "ctoken",
    aliases: [],
    permissions : [""],
    ownerOnly: true,
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {


        let token = args[0];

        let data = await tokenModel.findOne({token: token})

        if(!data) return message.reply({content: 'Invalid token'})

        if(data) {
            return message.channel.send({content: `Token found - Matches to ${data.userID}`})
        }

    }
}