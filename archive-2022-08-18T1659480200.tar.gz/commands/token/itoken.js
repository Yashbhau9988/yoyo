const { Message, Client } = require("discord.js");
const userModel = require("../../modals/vouches");
const vouchModel = require("../../modals/vouch");
const ee = require("../../settings/embed.json")
const checkModel = require("../../modals/checking");
const tokenModel = require("../../modals/users");
var sleep = require('thread-sleep');


module.exports = {
    name: "itoken",
    aliases: [],
    permissions : [""],
    ownerOnly: true,
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {



        let token = args[0];
        let userid = args.slice(1).join(" ")

        if(!userid) {
            return message.reply("Pls provide the new user's id!")
        }


        let member = client.users.cache.get(userid)

        let data = await tokenModel.findOne({token: token})
        if(!data) {
            return message.reply({content: 'Invalid token'})
        }

        let oldUserID = data.userID;

        let detete = await userModel.findOne({userID: oldUserID})

        let oldUserTAG = detete.userTAG;


        // await tokenModel.findOneAndUpdate({token: token}, {userID: userid})
        await userModel.deleteMany({userID: userid})
        sleep(2000)
        await tokenModel.deleteMany({userID: userid})
        sleep(2000)
        await vouchModel.deleteMany({userID: userid})
        sleep(2000)


        message.reply({content: 'Starting to update.'})

        await userModel.updateMany({userID: oldUserID}, {userID: userid})
        sleep(2000)
        await tokenModel.updateMany({userID: oldUserID}, {userID: userid})
        sleep(2000)
        await vouchModel.updateMany({userID: oldUserID}, {userID: userid})
        sleep(2000)
        await userModel.updateMany({userTAG: oldUserTAG}, {userTAG: member.tag})
        sleep(2000)

        message.channel.send({content: 'Finished.'})
       


    },
};