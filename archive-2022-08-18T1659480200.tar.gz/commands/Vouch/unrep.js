const {
    Message,
    Client,
    MessageEmbed,
    MessageActionRow,
    MessageButton,
  } = require("discord.js");
  const userModel = require("../../modals/vouches");
  const vouchesModel = require("../../modals/vouch");
  const tokenModel = require("../../modals/users");
  const scamModel = require("../../modals/scammer")
  const ee = require("../../settings/embed.json");
  const {CommandCooldown, msToMinutes} = require('discord-command-cooldown');
  const ms = require('ms');
  
  
  module.exports = {
    name: "unrep",
    aliases: [],
    permissions: ["SEND_MESSAGES"],
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {
  
      const timeSpan = ms('7 days')
  
      const createdAt = new Date(message.author.createdAt).getTime();
  
      let diffrence = Date.now() - createdAt;
  
      if(diffrence < timeSpan) {
        await message.react("❌");
        let embed = client.functions.failEmbed(
          "Failed!",
          "Minimum Account Age to vouch is 7days!"
        );
        return message.channel.send({ embeds: [embed] });
        
      }
    
      
  
      const vouchCooldown = new CommandCooldown('vouch', ms('1m'))
      const userCooldowned = await vouchCooldown.getUser(message.author.id);
  
      if(userCooldowned) { 
        const timeLeft = msToMinutes(userCooldowned.msLeft, false); // False for excluding '0' characters for each number < 10
        message.react("❌")
        message.reply(`You need to wait ${ timeLeft.seconds + ' seconds'} before running command again!`);
      } else {
  
        await vouchCooldown.addUser(message.author.id);
  
  
  
      if (!args[0]) {
        await message.react("❌");
        let embed = client.functions.failEmbed(
          "Failed!",
          "Use the correct command!\n`+unrep <user> comment`"
        );
        return message.channel.send({ embeds: [embed] });
      }
  
      let user = args.slice(0).join(" ")
  
      const regex = /(?<id>[0-9]{18})/i;
  
      let con = user.match(regex)
  
      let userid = con.groups.id;
             
      const member = client.users.cache.get(userid)
      if(!member) {
        let membed = client.functions.failEmbed("Failed", `<:cross:982377277801234452> Unable to find the user.`)
        return message.channel.send({embeds: [membed]})
      }
  
      let deek = await scamModel.findOne({userID: userid});
      if(deek) {
        await message.react("🚫")
        await message.reply({embeds: [
          new MessageEmbed()
          .setColor("RED")
          .setThumbnail(member.displayAvatarURL({ dynamic: false, size: 64, format: 'png' }))
          .setTitle(`${member.tag}'s info`)
          .setDescription(`<:cross:982377277801234452> The user is marked as a scammer, so this vouch cannot be counted.`)
          .setFooter({text: 'Reco'})
          .setTimestamp()
        ]})
        return;
      }
  
      if(member.id === message.author.id) {
        await message.react("🚫")
        await message.reply({embeds: [
          new MessageEmbed()
          .setColor("RED")
          .setThumbnail(member.displayAvatarURL({ dynamic: false, size: 64, format: 'png' }))
          .setAuthor({iconURL: 'https://cdn.discordapp.com/emojis/982377277801234452.webp?size=128&quality=lossless', name: 'Denied'})
          .setDescription("You cannot vouch yourself!")
          .setFooter({text: 'Reco'})
          .setTimestamp()
        ]})
        return;
      }
  
      let data = await userModel.findOne({ userID: userid });
      if (!data) {
        await new userModel({
          userID: userid,
          pen_vouches: 0,
          app_vouches: 0,
          dec_vouches: 0,
          unreps: 0,
          veri_vouches: 0,
          overall_vouches: 0,
        }).save();
      }
      let hi = await userModel.findOne({ userID: userid });
      let randNum = client.functions.randNum();
  
      if (!args[1]) {
        await message.react("<:cross:982377277801234452>");
        let embed = client.functions.failEmbed(
          "Failed!",
          "Use the correct command!\n`+unrep <user> comment`"
        );
        return message.channel.send({ embeds: [embed] });
      }
  
  
      
  
  
      await message.react("<:tickkk:982377244439760986>");
      let embedOne = new MessageEmbed()
        .setAuthor({
          name: "Success",
          iconURL:
            "https://cdn.discordapp.com/emojis/982377244439760986.webp?size=128&quality=lossless",
        })
        .setDescription(`You gave \`${member.tag}\` a negative vouch.`)
        .setColor(ee.embed_color)
        .setFooter({ text: "Reco", iconURL: ee.embed_footericon });
  
      // let embedOne = client.functions.successEmbed("Success!", `You gave \`${user.tag}\` a positive vouch.`)
      await message.channel.send({ embeds: [embedOne] }).then((m) => {
        function mdelete() {
          m.delete();
        }
        setTimeout(mdelete, 4000);
      });
  
      let newVouchCount = hi.unreps + 1;
      let over = hi.overall_vouches + 1;
  
      //  console.log(newVouchCount, over)
  
      // let true = { overall_vouches: over }
      await userModel.findOneAndUpdate(
        { userID: userid },
        { unreps: newVouchCount }
      );
      await userModel.findOneAndUpdate(
        { userID: userid },
        { overall_vouches: over }
      );
  
      let embedTwo = new MessageEmbed()
        .setAuthor({
          name: "Vouch Notification",
          iconURL:
            "https://cdn.discordapp.com/emojis/982389763380236318.gif?size=56&quality=lossless",
        })
        .setDescription(
          `You got a \`negative\` vouch from \`${message.author.tag}\` the vouch number is \`${randNum}\` and is waiting to be reviewed by our staff! `
        )
        .setColor(ee.embed_color)
        .setFooter({ text: "Reco", iconURL: ee.embed_footericon });
  
      // let embedTwo = client.functions.successEmbed("Success!", `You got a \`positive\` vouch from \`${message.author.tag}\` the vouch number is \`${randNum}\` and is waiting to be reviewed by our staff! `)
      await member.send({ embeds: [embedTwo] });
  
      let embedThree = new MessageEmbed()
        .setAuthor({
          name: "Vouch Information",
          iconURL:
            "https://cdn.discordapp.com/emojis/982389763380236318.gif?size=56&quality=lossless",
        })
        .setDescription(
          `> **New Negative vouch**\n__VOUCH INFO__\n\n**<:vhnum:982401075774636062> Vouch Number**: \`${randNum}\`\n\n**<:user:982400100418609172> Vouched User**: \`${
            member.tag
          } (${member.id})\`\n\n**<:user:982400100418609172> Vouched By**: \`${
            message.author.tag
          } (${
            message.author.id
          })\`\n\n**<:comment:982401508899430400> Comment**: \`${args
            .slice(1)
            .join(" ")}\``
        )
        .setFooter({ text: "Reco", iconURL: ee.embed_footericon })
        .setColor(ee.embed_color);
  
      let ch = "982719883781488660";
      let cha = client.channels.cache.get(ch);
      await cha.send({ embeds: [embedThree] });
  
      let daata = await new vouchesModel({
        userID: userid,
        userTAG: member.tag,
        vouchNum: randNum,
        comment: args.slice(1).join(" "),
        vouchAuthor: `${message.author.tag} (${message.author.id})`,
        Status: "Pending",
      });
      await daata.save();
    }
    },
  };
  