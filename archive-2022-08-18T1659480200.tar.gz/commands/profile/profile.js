const {
  MessageActionRow,
  Modal,
  TextInputComponent,
  Message,
  Client,
  MessageEmbed,
  Formatters,
} = require("discord.js");
const { default: fetch } = require("node-fetch");
const ee = require("../../settings/embed.json");
const vouchModel = require("../../modals/vouch");
const userModel = require("../../modals/vouches");
const tokenModel = require("../../modals/users");
const badgeEmojis = require("../../settings/badges.json");
const scamModel = require("../../modals/scammer");
var sleep = require('thread-sleep');


module.exports = {
  name: "profile",
  aliases: ["p"],
  permissions: ["SEND_MESSAGES"],
  description: 'Shows your profile to others.',
  /**
   *
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {

    const statuses = {
      online: "<a:Online:983108234556608573> Online",
      offline: "<:invisible:983109578193526824> Offline",
      dnd: "<a:mm_RedAlertsign:983108383555080232> DND",
      idle: "<:BRV_ios_moon_6:983108686182506516> Idle",
    };

    let user =
      message.mentions.users.first() ||
      client.users.cache.get(args[0]) ||
      message.author;

    const member = client.users.cache.get(user.id);

    let deek = await scamModel.findOne({ userID: user.id, scammer: "true" })
    if(deek) {
      await message.channel.send({embeds: [
        new MessageEmbed()
        .setTitle(`${member.tag}'s profile`)
        .setColor("RED")
        .setThumbnail(member.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: "Member Information" })
        .setImage("https://media.discordapp.net/attachments/982367994187513859/995647816074526750/unknown.png")
        .setTimestamp()
        .setDescription(`The user - ${user} is a known scammer, reported for \`${deek.reason}\`. Be aware while dealing with them.`)

      ]})
      return;
    }

    let dataa = await userModel.findOne({ userID: user.id });

    if (!dataa) {
      new userModel({
        userID: user.id,
        pen_vouches: 0,
        unreps: 0,
        app_vouches: 0,
        dec_vouches: 0,
        veri_vouches: 0,
        overall_vouches: 0,
      }).save();
    }

    let dete = await userModel.findOne({ userID: user.id });

    let ook = await tokenModel.findOne({ userID: user.id });

    let token = client.functions.randToken();

    if (!ook) {
     await new tokenModel({
        token: token,
        userID: user.id,
        badges: `${badgeEmojis["User"]} User`,
        shop: "Not Set",
      }).save();
    }
    
    sleep(0)

    let oook = await tokenModel.findOne({ userID: user.id });

    sleep(0)

    let detee = await userModel.findOne({ userID: user.id });

    let badg = oook.badges;

    //console.log(oook.badges)


      
     let h = badg.splice(",").join("\n")


     let pastVouches = await vouchModel.find({userID: user.id, Status: "Accepted"}, { _id: 0, vouchNum: 0, vouchAuthor: 0, userID: 0, userTAG: 0, Status: 0, __v: 0 }).limit(5)

     // console.log(pastVouches);
      
     if(!pastVouches) {
      let hqh = "No vouches to show."
     }

     let commentOne = pastVouches[0]?.comment || "No Vouches";
     let commentTwo = pastVouches[1]?.comment || "";
     let commentThree = pastVouches[2]?.comment || "";
     let commentFour = pastVouches[3]?.comment || "";
     let commentFive = pastVouches[4]?.comment || "";

     let hh = `${commentOne}\n${commentTwo}\n${commentThree}\n${commentFour}\n${commentFive}`

     // console.log(pastReturn)


    if (detee.pen_vouches < 0) {
      pen_vouches = 0;
    } else {
      pen_vouches = detee.pen_vouches;
    }

    const response = await fetch(
      `https://japi.rest/discord/v1/user/${user.id}`
    );
    const data = await response.json(); //public_flags_array

    let status = member.presence?.status;

    if (status === "dnd" || status === "idle" || status === "online")
      status = statuses[status];
    else if (
      status === "invisible" ||
      status === "offline" ||
      status === undefined
    )
      status = statuses["offline"];

    // const joinedAt = Formatters.time(member.joinedAt, "R");
    const createdAt = Formatters.time(member.createdAt, "R");

    let embed = new MessageEmbed()
      .setTitle(`${member.tag}'s profile`)
      .setThumbnail(member.displayAvatarURL({ dynamic: true }))
      .setColor(ee.embed_color)
      .setDescription(
        `**Member Mention:** <@${member.id}>\n**Member ID:** ${member.id}\n**Display Name:** ${member.username}\n**User Created:** ${createdAt}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Profile Vouches**:\n<:emoji_29:983467181507510323> Positive Vouches: ${detee.app_vouches}\n<:cross:982377277801234452> Negative Vouches: ${detee.unreps}\n<:tickkk:982377244439760986> Overall Vouches: ${detee.overall_vouches}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Badges:**\n${h}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Last 5 vouches:**\n${hh}`
      )
      .setFooter({ text: "Member Information" })
      .setTimestamp();

    await message.channel.send({ embeds: [embed] });
  },
};
