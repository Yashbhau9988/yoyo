const client = require("..");
const colors = require("colors")
const functions = require("../functions.js")

client.on('ready', async () => {
    console.log(`${client.user.username} Is Online`.green);
    client.user.setActivity(`gg/recobot`,{type : "PLAYING"});

 let readyEmbed = client.functions.successEmbed("Client Updates!", "Client is connected!")
   client.functions.logger("982942606436745216", readyEmbed)

  
})